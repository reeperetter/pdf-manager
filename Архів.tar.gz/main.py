import sys
from pathlib import Path
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton,
    QFileDialog, QTextEdit, QLabel, QMessageBox
)
from PyQt5.QtCore import Qt
from pypdf import PdfReader, PdfWriter


class PDFRotatorApp(QWidget):
    def __init__(self):
        super().__init__()
        self.selected_files = []
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Поворот PDF сторінок (+90°)")
        self.resize(500, 400)

        layout = QVBoxLayout()

        self.label_info = QLabel("Виберіть PDF-файли для повертання сторінок на 90° за годинниковою стрілкою:")
        self.label_info.setWordWrap(True)
        layout.addWidget(self.label_info)

        self.btn_select = QPushButton("Вибрати PDF файли")
        self.btn_select.clicked.connect(self.select_files)
        layout.addWidget(self.btn_select)

        self.text_log = QTextEdit()
        self.text_log.setReadOnly(True)
        layout.addWidget(self.text_log)

        self.btn_process = QPushButton("Повернути сторінки на 90°")
        self.btn_process.setEnabled(False)
        self.btn_process.clicked.connect(self.process_pdfs)
        layout.addWidget(self.btn_process)

        self.setLayout(layout)

    def select_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Виберіть PDF файли",
            "",
            "PDF Files (*.pdf)"
        )
        if files:
            self.selected_files = files
            self.text_log.clear()
            self.text_log.append(f"Обрано файлів: {len(files)}\n")
            for f in files:
                self.text_log.append(f"- {Path(f).name}")
            self.btn_process.setEnabled(True)

    def process_pdfs(self):
        if not self.selected_files:
            return

        success_count = 0
        self.text_log.append("\n--- Початок обробки ---")

        for file_path in self.selected_files:
            try:
                path = Path(file_path)
                reader = PdfReader(path)
                writer = PdfWriter()

                # Повертаємо кожну сторінку на 90 градусів за годинниковою стрілкою
                for page in reader.pages:
                    page.rotate(90)
                    writer.add_page(page)

                # Шлях для нового файлу з суфіксом _rotated
                output_path = path.with_name(f"{path.stem}_rotated{path.suffix}")

                with open(output_path, "wb") as out_file:
                    writer.write(out_file)

                self.text_log.append(f"Успішно: {output_path.name}")
                success_count += 1

            except Exception as e:
                self.text_log.append(f"Помилка при обробці {Path(file_path).name}: {str(e)}")

        self.text_log.append(f"\nЗавершено. Опрацьовано файлів: {success_count} з {len(self.selected_files)}")
        QMessageBox.information(self, "Готово", f"Успішно оброблено файлів: {success_count}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PDFRotatorApp()
    window.show()
    sys.exit(app.exec_())
